﻿using AngeloWongReservas.Modelo;
using System;


namespace AngeloWongReservas.Controlador
{
    public class ControladorReserva
    {
        private Reserva reserva;

        public ControladorReserva()
        {
            reserva = new Reserva();
        }

        public void SetDatosUsuario(string nombre)
        {
            //Guarda nombre proporcionado por Usuario
            reserva.Usuario = nombre;

        }

        public void SetCanchaSeleccionada(Cancha cancha)
        {
            //Guarda la cancha seleccionada
            reserva.CanchaReservada = cancha;
        }


        //Metodo para agregar un acompañante
        public void AgregarAcompanante(string nombre)
        {
            if (reserva.Acompanantes.Count < reserva.CanchaReservada.Capacidad)
            {
                reserva.Acompanantes.Add(new Acompanante { NombreAcompanante = nombre });
            }
            else
            {
                // Si se ha alcanzado el límite de acompañantes en la cancha que selecciono muestra una ventana emergente
                throw new Exception("Límite de acompañantes alcanzado.");
            }
        }



        //Método para obtener el nombre de la cancha que se selecciono en checkedListBox1
        public string GetV()
        {
            return $"Cancha: {reserva.CanchaReservada.Capacidad}\n";
        }

        //Metodo para generar la factura y mostrarla en una ventana emergente
        public string GenerarFactura(string v)
        {
            string factura = $"Factura para: {reserva.Usuario}\n"
                             + v + $"Precio: {reserva.CanchaReservada.Precio:C}\n"
                             + $"Acompañantes: {reserva.Acompanantes.Count}\n";

            foreach (var acompanante in reserva.Acompanantes)
            {
                factura += $" - {acompanante.NombreAcompanante} ()\n";
            }

            return factura;
        }
    }
}
