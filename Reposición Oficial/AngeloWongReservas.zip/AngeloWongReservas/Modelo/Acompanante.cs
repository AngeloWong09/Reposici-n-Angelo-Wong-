﻿namespace AngeloWongReservas.Modelo
{
    public class Acompanante
    {
        // Almacena el nombre del acompañante ingresado por el usuario
        public string NombreAcompanante { get; set; }
    }
}
