﻿
using System.Collections.Generic;

namespace AngeloWongReservas.Modelo
{
    public class Reserva
    {
        // Almacena el nombre del usuario que hace la reserva
        public string Usuario { get; set; }

        // Amacena la cancha seleccionada para la reserva
        public Cancha CanchaReservada { get; set; }

        // La lista que guardar los acompañantes
        public List<Acompanante> Acompanantes { get; set; } = new List<Acompanante>();
    }
}

