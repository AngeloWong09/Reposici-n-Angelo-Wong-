﻿
namespace AngeloWongReservas.Modelo
{
    public class Cancha
    {
        //Donde se va guardar el numero (id) de las canchas
        public int Id { get; set; }

        //Donde se guardara el nombre de la cancha
        public string Nombre { get; set; }

        //Donde se guardara la capacidad de jugadores en cada cancha
        public int Capacidad { get; set; }

        //Donde se guardara el precio establecido para las canchas 1,2 y 3.
        public decimal Precio { get; set; }
    }
}

