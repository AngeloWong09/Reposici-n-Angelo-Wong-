﻿using AngeloWongReservas.Controlador;
using AngeloWongReservas.Data;
using AngeloWongReservas.Modelo;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace AngeloWongReservas
{
    public partial class Form1 : Form
    {
        private ControladorReserva controller;
        private ServicioDatos dataService;
        private string facturaGenerada;
        private DateTimePicker dtpMes; 
        private ServicioDatosUsuario servicioDatosUsuario;

        public Form1()
        {
            InitializeComponent();
            controller = new ControladorReserva();
            dataService = new ServicioDatos();
            CargarCanchas();
            dtpHoraReserva.Format = DateTimePickerFormat.Time;
            dtpHoraReserva.ShowUpDown = true;
            listViewReportes.View = View.Details;
            listViewReportes.Columns.Add("Reporte", 400);
            servicioDatosUsuario = new ServicioDatosUsuario();
            dtpFechaReserva.Format = DateTimePickerFormat.Short;
            dtpMes = new DateTimePicker(); 
            dtpMes.Format = DateTimePickerFormat.Custom; 
            dtpMes.CustomFormat = "MM/yyyy"; 
            dtpMes.ShowUpDown = true; 
            dtpMes.Location = new Point(10, 10); 
            this.Controls.Add(dtpMes); 
            CargarUsuarios();
        }

        //Fue creado al hacer doble click en el From1
        private void Form1_Load(object sender, EventArgs e)
        {
           
        }



        //Se muestra los datos de Dataservice en el cuadro checkedListBox1
        private void CargarCanchas()
        {
            var canchas = dataService.CargarCanchas();
            foreach (var cancha in canchas)
            {
                checkedListBox1.Items.Add(cancha);
            }
            checkedListBox1.DisplayMember = "Nombre";
        }



        //Este metodo al ejecutarlo agreaga lo escrito en el cuadro txtNombreAcompanante a ListaAcompañante
        private void AgregarLista_Click_1(object sender, EventArgs e)
        {
            try
            {
                //Condicion si no se selecciona la cancha al agregar un acompañante
                if (checkedListBox1.CheckedItems.Count == 0)
                {
                    //Mensaje al no selecionar una cancha
                    MessageBox.Show("Debe seleccionar una cancha.");
                    return;
                }

                var canchaSeleccionada = (Cancha)checkedListBox1.CheckedItems[0];
                controller.SetCanchaSeleccionada(canchaSeleccionada);

                string nombreAcompanante = txtNombreAcompanante.Text;

                controller.AgregarAcompanante(nombreAcompanante);
                ListaAcompañante.Items.Add($"{nombreAcompanante}");

                txtNombreAcompanante.Clear();
            }
            catch (Exception ex)
            {
                //Muestra en una ventana emergente los datos agregados
                MessageBox.Show(ex.Message);
            }
        }

        // Metodo donde se obtiene los usuarios(encargados) del archivo Usuarios.txt de  y se muestran en listBoxUsuarios
        private void CargarUsuarios()
        {
            // Ruta del archivo Usuarios.txt
            string rutaArchivo = @"C:\Users\dell\source\repos\AngeloWongReservas\Usuario\Usuarios.txt";

            try
            {
                if (File.Exists(rutaArchivo))
                {
                    // Lee todas las líneas del archivo
                    string[] lineas = File.ReadAllLines(rutaArchivo);

                    // Limpiar el ListBox antes de agregar nuevos datos
                    listBoxUsuarios.Items.Clear();

                    // Agregar cada línea del archivo Usuarios.txt al ListBox
                    foreach (string linea in lineas)
                    {
                        listBoxUsuarios.Items.Add(linea.Trim());
                    }
                }
                //Ventana emergente en caso de que no se encuentre o encuentre el archivo Usaurios.txt
                else
                {
                    MessageBox.Show("El archivo Usuarios.txt no se encontró en la ruta especificada.", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al leer el archivo de usuarios: " + ex.Message, "Error");
            }
        }

        //Metodo que agrega el encargado seleccionado en listBoxUsuarios a txtNombreUsuario
        private void listBoxUsuarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxUsuarios.SelectedItem != null)
            {
                // Obtener el nombre del usuario seleccionado
                string usuarioSeleccionado = listBoxUsuarios.SelectedItem.ToString();
                // Actualizar txtNombreUsuario con el nombre del usuario seleccionado
                txtNombreUsuario.Text = usuarioSeleccionado;
            }

        }



        //Este metodo al ejecutarlo muestra en una ventana emergente los datos ingresados
        private void GenerarFactura_Click_1(object sender, EventArgs e)
        {
            //Condicion si se ejecuta el metodo sin haber seleccionado el nombre y cancha
            if (string.IsNullOrWhiteSpace(txtNombreUsuario.Text) ||
               checkedListBox1.CheckedItems.Count == 0)

            {
              
                MessageBox.Show("Debe llenar todos los datos de usuario y seleccionar una cancha.");
                return;
            }

            controller.SetDatosUsuario(txtNombreUsuario.Text);
            DateTime fechaReserva = dtpFechaReserva.Value;
            TimeSpan horaReserva = dtpHoraReserva.Value.TimeOfDay; // Obtener la hora de la computadora o sistema
            facturaGenerada = controller.GenerarFactura(controller.GetV());

            string factura = controller.GenerarFactura(controller.GetV());

            // Agregar la fecha y la hora de la reserva a la factura
            factura += $"Fecha de la reserva: {fechaReserva.ToShortDateString()}\n";
            factura += $"Hora de la reserva: {horaReserva.Hours:D2}:{horaReserva.Minutes:D2}\n"; 
            facturaGenerada = factura;
            MessageBox.Show(factura);
        }



        private void GuardarFacturaEnArchivo_Click_1(object sender, EventArgs e)
        {
            // Ruta del archivo. Los datos se guaradar en un .txt dentro de una carpeta llamda Archivo
            string rutaCarpeta = @"C:\Users\dell\source\repos\AngeloWongReservas\Archivo";
            //Nombre del archivo .txt donde se guardara los datos generados
            string rutaArchivo = Path.Combine(rutaCarpeta, "Reportes.txt");

            try
            {
                // Condicion para corroborar que la carpeta exista
                if (!Directory.Exists(rutaCarpeta))
                {
                    Directory.CreateDirectory(rutaCarpeta);
                }

                // Obtener la cancha seleccionada en el checkedListBox1
                Cancha canchaSeleccionada = (Cancha)checkedListBox1.CheckedItems[0];

                // Estructura de la factura
                string datosFactura = $"Factura hecha por: {txtNombreUsuario.Text}\n" 
                                      + $"Numero de Cancha: {canchaSeleccionada.Nombre}\n" 
                                      + $"Precio: {canchaSeleccionada.Precio:C}\n" 
                                      + $"Fecha de la reserva: {dtpFechaReserva.Value.ToShortDateString()}\n"
                                      + $"Hora de la reserva: {dtpHoraReserva.Value.ToString("HH:mm")}\n"
                                      + $"Acompañantes agregados: {ListaAcompañante.Items.Count}\n";

                foreach (var item in ListaAcompañante.Items)
                {
                    datosFactura += $" - {item}\n"; // Mostrar nombre de los acompañantes en una lista
                }

                // Añadir la nueva información al archivo
                File.AppendAllText(rutaArchivo, datosFactura + "\n\n"); // Añadir un separador entre facturas

                MessageBox.Show($"Factura guardada en archivo: {rutaArchivo}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar la factura: {ex.Message}");
            }
        }





        //Metodo que flitrara los datos en Reporte.txt para mostrar las horas repetidas 
        private void btnHorasUtilizadas_Click(object sender, EventArgs e)
        {
            //Ruta en donde buscara los datos para mostrarlos en listViewReportes
            string rutaArchivo = @"C:\Users\dell\source\repos\AngeloWongReservas\Archivo\Reportes.txt";

            try
            {
                if (File.Exists(rutaArchivo))
                {
                    // Lee todas las líneas del archivo Reportes.txt
                    string[] lineas = File.ReadAllLines(rutaArchivo);

                    // Aqui empieza a contar las horas más utilizadas por la factura en el archivo Reporte.txt
                    Dictionary<string, Dictionary<string, int>> conteoHorasPorCancha = new Dictionary<string, Dictionary<string, int>>();

                    // Filtrar el mes y año seleccionados en dateTimePickerMes en el archivo Reporte.txt
                    DateTime mesSeleccionado = dateTimePickerMes.Value;
                    int mes = mesSeleccionado.Month;
                    int anio = mesSeleccionado.Year;

                    // Procesar cada línea del archivo
                    string canchaActual = null;

                    foreach (string linea in lineas)
                    {
                        // Detectar la cancha en el archivo
                        if (linea.StartsWith("Numero de Cancha:"))
                        {
                            canchaActual = linea.Split(':')[1].Trim();
                            if (!conteoHorasPorCancha.ContainsKey(canchaActual))
                            {
                                conteoHorasPorCancha[canchaActual] = new Dictionary<string, int>();
                            }
                        }

                        // Verificacion si la línea contiene la fecha y está dentro del mes seleccionado en dateTimePickerMes
                        if (linea.StartsWith("Fecha de la reserva:"))
                        {
                            DateTime fechaReserva = DateTime.Parse(linea.Split(':')[1].Trim());

                            // Filtrar reservas dentro del mes seleccionado
                            if (fechaReserva.Month != mes || fechaReserva.Year != anio)
                            {
                                canchaActual = null; 
                            }
                        }

                        if (canchaActual != null && linea.StartsWith("Hora de la reserva:"))
                        {
                            // Extraer la hora de la línea
                            string hora = linea.Split(':')[1].Trim();

                            // Contar las ocurrencias de cada hora en las cancha
                            if (conteoHorasPorCancha[canchaActual].ContainsKey(hora))
                            {
                                conteoHorasPorCancha[canchaActual][hora]++;
                            }
                            else
                            {
                                conteoHorasPorCancha[canchaActual][hora] = 1;
                            }
                        }
                    }

                    listViewReportes.Items.Clear();

                    // Encontrar la hora más utilizada por cada cancha y agregar al ListView
                    foreach (var cancha in conteoHorasPorCancha)
                    {
                        string canchaNombre = cancha.Key;
                        var horas = cancha.Value;

                        if (horas.Count > 0)
                        {
                            var horaMasUtilizada = horas.OrderByDescending(h => h.Value).First();
                            ListViewItem item = new ListViewItem($"{canchaNombre} - Hora más utilizada: {horaMasUtilizada.Key} ({horaMasUtilizada.Value} veces)");
                            listViewReportes.Items.Add(item);
                        }
                        else
                        {
                            ListViewItem item = new ListViewItem($"{canchaNombre} - No hay datos en el mes seleccionado.");
                            listViewReportes.Items.Add(item);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("El archivo Reportes.txt no se encontró en la ruta especificada.", "Error");
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("El archivo Reportes.txt no se encontró.", "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al leer el archivo: " + ex.Message, "Error");
            }
        }



        //Metodo que flitrara los datos en Reporte.txt para mostrar la cual de las canchas ha generado mas sumando sus precios
        private void btnIngresopormes_Click(object sender, EventArgs e)
        {
            // Ruta en donde buscara los datos para mostrarlos en listViewReportes
            string rutaArchivo = @"C:\Users\dell\source\repos\AngeloWongReservas\Archivo\Reportes.txt";

            try
            {
                if (File.Exists(rutaArchivo))
                {
                    // Lee todas las líneas del archivo Reportes.txt
                    string[] lineas = File.ReadAllLines(rutaArchivo);

                    // Diccionario para almacenar los datos
                    Dictionary<string, decimal> ingresosPorCancha = new Dictionary<string, decimal>();

                    // Obtener el mes y año seleccionado del dateTimePickerMes2
                    DateTime fechaSeleccionada = dateTimePickerMes2.Value;
                    int mesSeleccionado = fechaSeleccionada.Month;
                    int anioSeleccionado = fechaSeleccionada.Year;

                    string canchaActual = "";
                    decimal precioActual = 0;

                    // Procesar cada línea del archivo
                    foreach (string linea in lineas)
                    {
                        if (linea.StartsWith("Numero de Cancha:"))
                        {
                            
                            canchaActual = linea.Split(':')[1].Trim();
                        }
                        else if (linea.StartsWith("Precio:"))
                        {
                            // Extraer el precio, eliminando cualquier símbolo de moneda y espacios
                            string precioTexto = linea.Split(':')[1].Trim().Replace("₡", "").Replace(",", "").Trim();
                            precioActual = decimal.Parse(precioTexto);
                        }
                        else if (linea.StartsWith("Fecha de la reserva:"))
                        {
                            // Extraer la fecha de la reserva y convertirla a DateTime
                            DateTime fechaReserva = DateTime.Parse(linea.Split(':')[1].Trim());

                            // Filtrar por el mes y año seleccionado
                            if (fechaReserva.Month == mesSeleccionado && fechaReserva.Year == anioSeleccionado)
                            {
                                // Sumar el precio al total de ingresos de las facturas de las canchas de Reporte.txt
                                if (ingresosPorCancha.ContainsKey(canchaActual))
                                {
                                    ingresosPorCancha[canchaActual] += precioActual;
                                }
                                else
                                {
                                    ingresosPorCancha[canchaActual] = precioActual;
                                }
                            }
                        }
                    }

                    listViewReportes.Items.Clear(); // Limpiar ListView antes de agregar nuevos datos

                    if (ingresosPorCancha.Count > 0)
                    {
                        // Agregar al ListView los ingresos por Reporte.txt
                        foreach (var ingreso in ingresosPorCancha)
                        {
                            ListViewItem item = new ListViewItem($"Cancha: {ingreso.Key} - Ingresos: ₡{ingreso.Value:N2}");
                            listViewReportes.Items.Add(item);
                        }
                    }
                    else
                    {
                        ListViewItem item = new ListViewItem("No se encontraron registros para el mes y año seleccionados.");
                        listViewReportes.Items.Add(item);
                    }
                }
                else
                //Ventana emergentes por si no esncontro la ruta, el archivo o si no puede encontrar el Reportes.txt   
                {
                    MessageBox.Show("El archivo Reportes.txt no se encontró en la ruta especificada.", "Error");
                }
            }
            catch (FileNotFoundException)
            {
                MessageBox.Show("El archivo Reportes.txt no se encontró.", "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al leer el archivo: " + ex.Message, "Error");
            }
        }


        private void btnImprimirFactura_Click_1(object sender, EventArgs e)
        {
            // Ruta del directorio donde se guardarán las facturas creadas
            string rutaDirectorio = @"C:\Users\dell\source\repos\AngeloWongReservas\Facturas";

            // Obtener el número de la última factura
            int numeroFactura = 1;
            if (Directory.Exists(rutaDirectorio))
            {
                var archivos = Directory.GetFiles(rutaDirectorio, "Factura_*.txt");
                if (archivos.Length > 0)
                {
                    // Obtener el número de la última factura
                    var ultimoArchivo = archivos.Select(Path.GetFileNameWithoutExtension)
                                                .OrderByDescending(nombre => nombre)
                                                .FirstOrDefault();
                    if (ultimoArchivo != null)
                    {
                        var partes = ultimoArchivo.Split('_');
                        if (partes.Length > 1 && int.TryParse(partes[1], out int ultimoNumero))
                        {
                            numeroFactura = ultimoNumero + 1;
                        }
                    }
                }
            }

            // Generar el nombre del archivo con el número de factura y la fecha actual
            string nombreArchivo = $"Factura_{numeroFactura:D3}_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string rutaArchivo = Path.Combine(rutaDirectorio, nombreArchivo);

            try
            {
                // Verificar si la carpeta existe, si no, crearla
                if (!Directory.Exists(rutaDirectorio))
                {
                    Directory.CreateDirectory(rutaDirectorio);
                }

                // Crear o sobreescribir el archivo de la factura
                using (StreamWriter writer = new StreamWriter(rutaArchivo))
                {
                    // Reemplaza estos datos con los reales
                    writer.WriteLine("Factura No: " + numeroFactura.ToString("D3"));
                    writer.WriteLine("Cliente: " + txtNombreUsuario.Text); // Usar el valor de txtNombreUsuario
                    writer.WriteLine("Fecha: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    writer.WriteLine("Cancha: " + ((Cancha)checkedListBox1.CheckedItems[0]).Nombre);
                    writer.WriteLine("Precio: ₡" + ((Cancha)checkedListBox1.CheckedItems[0]).Precio.ToString("N2"));
                    writer.WriteLine("Fecha de la reserva: " + dtpFechaReserva.Value.ToShortDateString());
                    writer.WriteLine("Hora de la reserva: " + dtpHoraReserva.Value.ToString("HH:mm"));
                    writer.WriteLine("Acompañantes: " + ListaAcompañante.Items.Count);
                    writer.WriteLine("Detalles:");
                    foreach (var item in ListaAcompañante.Items)
                    {
                        writer.WriteLine(" - " + item);
                    }
                }

                MessageBox.Show("Factura guardada exitosamente en " + rutaArchivo, "Éxito");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error al guardar la factura: " + ex.Message, "Error");
            }
        }

        //Metdodo que muestra todos los datos de Reporte.txt
        private void btnMostrarReportes_Click_1(object sender, EventArgs e)
        {
            //Ruta para buscar el archivo .txt Reportes.txt
            string rutaArchivo = @"C:\Users\dell\source\repos\AngeloWongReservas\Archivo\Reportes.txt";

            try
            {
                if (File.Exists(rutaArchivo))
                {
                    // Limpia el listViewReportes
                    listViewReportes.Items.Clear();

                    // Lee todas las líneas del archivo Reportes.txt
                    string[] lineas = File.ReadAllLines(rutaArchivo);

                    // Añade en cada línea un ítem en el listViewReportes
                    foreach (string linea in lineas)
                    {
                        ListViewItem item = new ListViewItem(linea);
                        listViewReportes.Items.Add(item);
                    }
                }
                else
                {
                    MessageBox.Show("El archivo de reportes no se encontró en la ruta especificada.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al leer el archivo de reportes: {ex.Message}");
            }

        }

    }
}


