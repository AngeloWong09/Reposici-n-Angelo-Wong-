﻿namespace AngeloWongReservas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.AgregarLista = new System.Windows.Forms.Button();
            this.txtNombreUsuario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombreAcompanante = new System.Windows.Forms.TextBox();
            this.ListaAcompañante = new System.Windows.Forms.ListView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.GenerarFactura = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtpFechaReserva = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.GuardarFacturaEnArchivo = new System.Windows.Forms.Button();
            this.listViewReportes = new System.Windows.Forms.ListView();
            this.dtpHoraReserva = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.btnMostrarReportes = new System.Windows.Forms.Button();
            this.btnHorasUtilizadas = new System.Windows.Forms.Button();
            this.btnIngresopormes = new System.Windows.Forms.Button();
            this.dateTimePickerMes = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerMes2 = new System.Windows.Forms.DateTimePicker();
            this.btnImprimirFactura = new System.Windows.Forms.Button();
            this.listBoxUsuarios = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(816, 50);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(228, 72);
            this.checkedListBox1.TabIndex = 0;
            // 
            // AgregarLista
            // 
            this.AgregarLista.Location = new System.Drawing.Point(816, 211);
            this.AgregarLista.Name = "AgregarLista";
            this.AgregarLista.Size = new System.Drawing.Size(228, 49);
            this.AgregarLista.TabIndex = 1;
            this.AgregarLista.Text = "Agregar acompañante";
            this.AgregarLista.UseVisualStyleBackColor = true;
            this.AgregarLista.Click += new System.EventHandler(this.AgregarLista_Click_1);
            // 
            // txtNombreUsuario
            // 
            this.txtNombreUsuario.Location = new System.Drawing.Point(561, 136);
            this.txtNombreUsuario.Name = "txtNombreUsuario";
            this.txtNombreUsuario.Size = new System.Drawing.Size(207, 22);
            this.txtNombreUsuario.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(813, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(231, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Escriba el nombre de  acompañantes";
            // 
            // txtNombreAcompanante
            // 
            this.txtNombreAcompanante.Location = new System.Drawing.Point(816, 162);
            this.txtNombreAcompanante.Name = "txtNombreAcompanante";
            this.txtNombreAcompanante.Size = new System.Drawing.Size(228, 22);
            this.txtNombreAcompanante.TabIndex = 4;
            // 
            // ListaAcompañante
            // 
            this.ListaAcompañante.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListaAcompañante.HideSelection = false;
            this.ListaAcompañante.Location = new System.Drawing.Point(1062, 50);
            this.ListaAcompañante.Name = "ListaAcompañante";
            this.ListaAcompañante.Size = new System.Drawing.Size(167, 292);
            this.ListaAcompañante.TabIndex = 10;
            this.ListaAcompañante.UseCompatibleStateImageBehavior = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(813, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Seleccione la cancha";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1059, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Acompañantes agregados";
            // 
            // GenerarFactura
            // 
            this.GenerarFactura.BackColor = System.Drawing.Color.Azure;
            this.GenerarFactura.Location = new System.Drawing.Point(557, 297);
            this.GenerarFactura.Name = "GenerarFactura";
            this.GenerarFactura.Size = new System.Drawing.Size(204, 45);
            this.GenerarFactura.TabIndex = 13;
            this.GenerarFactura.Text = "Ver Factura";
            this.GenerarFactura.UseVisualStyleBackColor = false;
            this.GenerarFactura.Click += new System.EventHandler(this.GenerarFactura_Click_1);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(73, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(561, 101);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(202, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Nombre del encargado en hacer";
            // 
            // dtpFechaReserva
            // 
            this.dtpFechaReserva.Location = new System.Drawing.Point(559, 188);
            this.dtpFechaReserva.Name = "dtpFechaReserva";
            this.dtpFechaReserva.Size = new System.Drawing.Size(200, 22);
            this.dtpFechaReserva.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(558, 165);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(207, 16);
            this.label10.TabIndex = 22;
            this.label10.Text = "Seleccione la fecha de la reserva";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // GuardarFacturaEnArchivo
            // 
            this.GuardarFacturaEnArchivo.BackColor = System.Drawing.Color.Azure;
            this.GuardarFacturaEnArchivo.Location = new System.Drawing.Point(816, 301);
            this.GuardarFacturaEnArchivo.Name = "GuardarFacturaEnArchivo";
            this.GuardarFacturaEnArchivo.Size = new System.Drawing.Size(228, 45);
            this.GuardarFacturaEnArchivo.TabIndex = 23;
            this.GuardarFacturaEnArchivo.Text = "Guardar Factura";
            this.GuardarFacturaEnArchivo.UseVisualStyleBackColor = false;
            this.GuardarFacturaEnArchivo.Click += new System.EventHandler(this.GuardarFacturaEnArchivo_Click_1);
            // 
            // listViewReportes
            // 
            this.listViewReportes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listViewReportes.HideSelection = false;
            this.listViewReportes.Location = new System.Drawing.Point(12, 12);
            this.listViewReportes.Name = "listViewReportes";
            this.listViewReportes.Size = new System.Drawing.Size(504, 330);
            this.listViewReportes.TabIndex = 24;
            this.listViewReportes.UseCompatibleStateImageBehavior = false;
            // 
            // dtpHoraReserva
            // 
            this.dtpHoraReserva.Location = new System.Drawing.Point(559, 237);
            this.dtpHoraReserva.Name = "dtpHoraReserva";
            this.dtpHoraReserva.Size = new System.Drawing.Size(200, 22);
            this.dtpHoraReserva.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(559, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(201, 16);
            this.label8.TabIndex = 30;
            this.label8.Text = "Seleccione la hora de la reserva";
            // 
            // btnMostrarReportes
            // 
            this.btnMostrarReportes.BackColor = System.Drawing.Color.Azure;
            this.btnMostrarReportes.Location = new System.Drawing.Point(193, 377);
            this.btnMostrarReportes.Name = "btnMostrarReportes";
            this.btnMostrarReportes.Size = new System.Drawing.Size(138, 49);
            this.btnMostrarReportes.TabIndex = 32;
            this.btnMostrarReportes.Text = "Mostrar todos los reportes";
            this.btnMostrarReportes.UseVisualStyleBackColor = false;
            this.btnMostrarReportes.Click += new System.EventHandler(this.btnMostrarReportes_Click_1);
            // 
            // btnHorasUtilizadas
            // 
            this.btnHorasUtilizadas.BackColor = System.Drawing.Color.Azure;
            this.btnHorasUtilizadas.Location = new System.Drawing.Point(29, 405);
            this.btnHorasUtilizadas.Name = "btnHorasUtilizadas";
            this.btnHorasUtilizadas.Size = new System.Drawing.Size(158, 49);
            this.btnHorasUtilizadas.TabIndex = 33;
            this.btnHorasUtilizadas.Text = "Horas mas utilizadas en canchas";
            this.btnHorasUtilizadas.UseVisualStyleBackColor = false;
            this.btnHorasUtilizadas.Click += new System.EventHandler(this.btnHorasUtilizadas_Click);
            // 
            // btnIngresopormes
            // 
            this.btnIngresopormes.BackColor = System.Drawing.Color.Azure;
            this.btnIngresopormes.Location = new System.Drawing.Point(337, 405);
            this.btnIngresopormes.Name = "btnIngresopormes";
            this.btnIngresopormes.Size = new System.Drawing.Size(179, 49);
            this.btnIngresopormes.TabIndex = 34;
            this.btnIngresopormes.Text = "Ingreso por mes en canchas";
            this.btnIngresopormes.UseVisualStyleBackColor = false;
            this.btnIngresopormes.Click += new System.EventHandler(this.btnIngresopormes_Click);
            // 
            // dateTimePickerMes
            // 
            this.dateTimePickerMes.CustomFormat = "MMMM yyyy";
            this.dateTimePickerMes.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMes.Location = new System.Drawing.Point(29, 377);
            this.dateTimePickerMes.Name = "dateTimePickerMes";
            this.dateTimePickerMes.ShowUpDown = true;
            this.dateTimePickerMes.Size = new System.Drawing.Size(158, 22);
            this.dateTimePickerMes.TabIndex = 35;
            // 
            // dateTimePickerMes2
            // 
            this.dateTimePickerMes2.CustomFormat = "MMMM yyyy";
            this.dateTimePickerMes2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMes2.Location = new System.Drawing.Point(337, 377);
            this.dateTimePickerMes2.Name = "dateTimePickerMes2";
            this.dateTimePickerMes2.ShowUpDown = true;
            this.dateTimePickerMes2.Size = new System.Drawing.Size(179, 22);
            this.dateTimePickerMes2.TabIndex = 36;
            // 
            // btnImprimirFactura
            // 
            this.btnImprimirFactura.BackColor = System.Drawing.Color.Azure;
            this.btnImprimirFactura.Location = new System.Drawing.Point(719, 373);
            this.btnImprimirFactura.Name = "btnImprimirFactura";
            this.btnImprimirFactura.Size = new System.Drawing.Size(167, 41);
            this.btnImprimirFactura.TabIndex = 37;
            this.btnImprimirFactura.Text = "Imprimir Factura";
            this.btnImprimirFactura.UseVisualStyleBackColor = false;
            this.btnImprimirFactura.Click += new System.EventHandler(this.btnImprimirFactura_Click_1);
            // 
            // listBoxUsuarios
            // 
            this.listBoxUsuarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxUsuarios.ForeColor = System.Drawing.SystemColors.WindowText;
            this.listBoxUsuarios.FormattingEnabled = true;
            this.listBoxUsuarios.ItemHeight = 16;
            this.listBoxUsuarios.Location = new System.Drawing.Point(559, 50);
            this.listBoxUsuarios.Name = "listBoxUsuarios";
            this.listBoxUsuarios.Size = new System.Drawing.Size(202, 36);
            this.listBoxUsuarios.TabIndex = 38;
            this.listBoxUsuarios.SelectedIndexChanged += new System.EventHandler(this.listBoxUsuarios_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(558, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 16);
            this.label3.TabIndex = 39;
            this.label3.Text = "Seleccione su nombre y cedula";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 355);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "Seleccione un mes y año";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(334, 355);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(157, 16);
            this.label9.TabIndex = 41;
            this.label9.Text = "Seleccione un mes y año";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(561, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(148, 16);
            this.label11.TabIndex = 42;
            this.label11.Text = "la reservacion al cliente";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ClientSize = new System.Drawing.Size(1330, 510);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.listBoxUsuarios);
            this.Controls.Add(this.btnImprimirFactura);
            this.Controls.Add(this.dateTimePickerMes2);
            this.Controls.Add(this.dateTimePickerMes);
            this.Controls.Add(this.btnIngresopormes);
            this.Controls.Add(this.btnHorasUtilizadas);
            this.Controls.Add(this.btnMostrarReportes);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dtpHoraReserva);
            this.Controls.Add(this.listViewReportes);
            this.Controls.Add(this.GuardarFacturaEnArchivo);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dtpFechaReserva);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.GenerarFactura);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ListaAcompañante);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNombreAcompanante);
            this.Controls.Add(this.txtNombreUsuario);
            this.Controls.Add(this.AgregarLista);
            this.Controls.Add(this.checkedListBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button AgregarLista;
        private System.Windows.Forms.TextBox txtNombreUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombreAcompanante;
        private System.Windows.Forms.ListView ListaAcompañante;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button GenerarFactura;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpFechaReserva;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button GuardarFacturaEnArchivo;
        private System.Windows.Forms.ListView listViewReportes;
        private System.Windows.Forms.DateTimePicker dtpHoraReserva;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnMostrarReportes;
        private System.Windows.Forms.Button btnHorasUtilizadas;
        private System.Windows.Forms.Button btnIngresopormes;
        private System.Windows.Forms.DateTimePicker dateTimePickerMes;
        private System.Windows.Forms.DateTimePicker dateTimePickerMes2;
        private System.Windows.Forms.Button btnImprimirFactura;
        private System.Windows.Forms.ListBox listBoxUsuarios;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
    }
}

