﻿using AngeloWongReservas.Modelo;
using System.Collections.Generic;


namespace AngeloWongReservas.Data
{
    public class ServicioDatos
    {
        public List<Cancha> CargarCanchas()
        {
            // Datos de las canchas y precios que se muestran en checkedListBox1 y que el responsable selecionara
            //Basado en la estructura de datos de Canchas.cs
            return new List<Cancha>
            {
                new Cancha { Id = 1, Nombre = "Cancha 1 (10 jugadores)", Capacidad = 10, Precio = 5000 },
                new Cancha { Id = 2, Nombre = "Cancha 2 (12 jugadores)", Capacidad = 12, Precio = 6500 },
                new Cancha { Id = 3, Nombre = "Cancha 3 (14 jugadores)", Capacidad = 14, Precio = 7000 }
            };
        }
    }
}

