﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AngeloWongReservas.Data
{
    public class ServicioDatosUsuario
    {
        // Ruta del archivo donde se almacenan los datos de los usuarios
        private const string RutaArchivoUsuarios = @"C:\Users\dell\source\repos\AngeloWongReservas\Usuario\Usuarios.txt";

        public List<Usuario> CargarListaUsuarios()
        {
            var listaUsuarios = new List<Usuario>();

            // Validación de la existencia del archivo
            if (!File.Exists(RutaArchivoUsuarios))
            {
                throw new FileNotFoundException("No se pudo localizar el archivo de usuarios.", RutaArchivoUsuarios);
            }

            var lineas = File.ReadAllLines(RutaArchivoUsuarios);

            foreach (var linea in lineas)
            {
                var partes = linea.Split(',');

                if (partes.Length != 2)
                {
                    // Manejo del error en caso de que el archivo no tenga el formato adecuado
                    throw new FormatException("El formato del archivo de usuarios no es válido.");
                }

                var usuario = new Usuario
                {
                    Nombre = partes[0].Trim(),
                    CorreoElectronico = partes[1].Trim()
                };

                listaUsuarios.Add(usuario);
            }

            return listaUsuarios;
        }
    }

    public class Usuario
    {
        public string Nombre { get; set; }
        public string CorreoElectronico { get; set; }
    }
}
